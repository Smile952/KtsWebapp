import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import './Services.css';
import { synchronizeToken } from '../../common/synchronizeToken';
import { UnauthorizedPage } from '../../js/pages/UnauthorizedPage';

interface Block {
    id: number;
    title: string;
    description: string;
    photo: string;
}

interface ImagesDataItem {
    ImageURL: string;
}

interface ImagesResponse {
    ImagesData: ImagesDataItem[];
}

export function Services() {
    const [isAuthorized, setIsAuthorized] = useState(false);
    const [blocks, setBlocks] = useState<Block[]>([
        { id: 1, title: 'Web Разработка', description: 'Создание и разработка современных сайтов и приложений', photo: '' },
        { id: 2, title: 'Android/iOS', description: 'Разработка приложений для iOS и Android', photo: '' },
        { id: 3, title: 'DevOps и облако', description: 'Настройка инфраструктуры и автоматизация процессов', photo: '' }
    ]);

    const nav = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            setIsAuthorized(true);
        }
    }, []);

    useEffect(() => {
        getImagesNames()
            .then(result => {
                const updated = [...blocks];
                // Здесь важно, чтобы result.ImagesData было не пустым и имело 3 элемента
                if (result?.ImagesData?.length >= 3) {
                    updated[1].photo = result.ImagesData[0].ImageURL;
                    updated[2].photo = result.ImagesData[1].ImageURL;
                    updated[0].photo = result.ImagesData[2].ImageURL;
                    setBlocks(updated);
                }
            })
            .catch(error => console.log('Ошибка при получении изображений: ', error));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const token = localStorage.getItem('token');
    const validate = synchronizeToken(token);
    if (!validate) {
        return <UnauthorizedPage />;
    }

    const handler = (id: number, block: Block) => {
        nav(`/about/${id}`, { state: block });
    };

    return (
        <div className='blocks'>
            <div className='blocks-group'>
                {blocks.map(block => (
                    <div key={block.id} onClick={() => handler(block.id, block)} className='back-blocks'>
                        <div className="front-blocks">
                            <div className='blocks-text'>
                                <div className="blocks-title">{block.title}</div>
                                <div className="blocks-description">{block.description}</div>
                                <div className="blocks-image">
                                    <img className="blocks-image-source" src={block.photo} alt={block.title} />
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

async function getImagesNames(): Promise<ImagesResponse> {
    const token = localStorage.getItem('token');
    const res = await fetch("https://localhost:8080/api/minio/images", {
        method: "GET",
        headers: {
            'Authorization': 'Bearer ' + token,
        },
    });

    if (!res.ok) {
        throw new Error('Failed to fetch images');
    }

    const ans = await res.json();
    return ans;
}
