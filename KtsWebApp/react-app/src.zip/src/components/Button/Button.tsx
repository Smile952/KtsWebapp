import './Button.css';

export function Button() {
    return (
        <div className="button-request">
            <input type="submit" className="btn btn-outline-success" />
        </div>
    );
}
