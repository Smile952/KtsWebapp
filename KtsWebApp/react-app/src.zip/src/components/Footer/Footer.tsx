import './Footer.css';

export function Footer() {
    return (
        <footer className="g-body-tertiary text-center text-lg-start footer">
            <div className="text-center p-3 footer-content">
                <p>© Права защищены Кунг-Фу пандой</p>
            </div>
        </footer>
    );
}
